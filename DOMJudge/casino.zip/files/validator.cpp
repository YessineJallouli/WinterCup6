#include <iostream>
#include <vector>
#include <cmath>
#include <map>
#include <numeric>
#include <algorithm>
#include <optional>
#include "testlib.h"

using integer =std::int64_t;
using real = long double;

int main(int argc, char** argv)
{
    registerValidation(argc, argv);
    integer L=inf.readInt();
    inf.readSpace();
    integer G=inf.readInt();
    inf.readEoln();
    ensuref((L / G) >=5,"Too many games");
    for(int i=0;i<L;i++)
    {
        real x=inf.readDouble();
        if(i<L-1)
            inf.readSpace();
        ensuref(0<=x && x<=1,"Invalid input");
    }
    inf.readEoln();
    inf.readEof();
}
