#include <iostream>
#include <vector>
#include <cmath>
#include <map>
#include <numeric>
#include <algorithm>
#include <optional>
#include "testlib.h"

using integer =std::int64_t;
using real = long double;
constexpr real p=0.42;


constexpr integer A=20e6;


int main(int argc, char** argv)
{
    // This command initializes checker environment.
    registerTestlibCmd(argc, argv);
    integer G=ouf.readInt();
    
    integer score=0;
    for(int i=0;i<G;i++)
    {
        real S1=ouf.readDouble(),S2=ouf.readDouble();
        if(S1 <= 1 && (S2 <= S1 || S2 > 1))
            score++;
    }
    real scoreRatio=score/(real)G;
    if(G<100000)
        quitf(_ok,"Number of games is not enough to conclude, skipping test");
    else if(scoreRatio < p)
        quitf(_wa,"Score ratio is too low, %Lf",scoreRatio);
    else
        quitf(_ok,"Score ratio is %Lf",scoreRatio);

}
