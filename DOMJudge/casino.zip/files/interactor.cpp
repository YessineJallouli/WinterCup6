//
// Created by ramizouari on 07/02/23.
//
#include <iostream>
#include <vector>
#include <optional>
#include "testlib.h"

using integer =std::int64_t;
using real = long double;

int main(int argc, char** argv)
{
    // This command initializes checker environment.
    registerInteraction(argc, argv);

    // Now there are three global variables specifying testlib streams:
    // inf - stream with the testdata.
    // ouf - stream with the contestant output.
    // ans - stream with the jury answer.
    // All those streams provide the similar interface for reading data.
    integer L=inf.readInt(),G=inf.readInt();
    integer score=0;
    std::vector<real> Z(L);
    for(int i=0;i<L;i++)
        Z[i]=inf.readDouble();
    int a=0,b=L-1;
    tout << G << std::endl;
    std::cout << G << std::endl;
    for(int i=0;i<G;i++)
    {
        std::cout << "G" << std::endl;
        real S1=0,S2=0;
        while(ouf.readInt() && S1 <= 1)
            std::cout << 'S'  << ' ' << (S1+=Z[a++]) << std::endl;
        while(S1 <= 1 && S2 < S1)
            S2+=Z[b--];
        if(S1 <= 1 && S2 > 1)
            std::cout << "W" << std::endl;
        else
            std::cout << "L" << std::endl;
        tout << S1 << ' ' << S2 << std::endl;
    }
   quitf(_ok,"All games were played");

}
