//
// Created by ramizouari on 06/02/23.
//
#include <iostream>
#include <random>

using real=long double;

int main(int argc, char **argv)
{
    std::uint64_t seed=0;
    int L,G;
    if(argc<3)
        return 1;
    else
    {
        L=std::stoi(argv[1]);
        G=std::stoi(argv[2]);
    }
    if(argc>3)
        seed=std::stoull(argv[3]);
    else {
        std::random_device dev;
        seed=dev();
    }
    std::mt19937_64 g(seed);
    std::uniform_real_distribution<real> d(0,1);
    std::cout.precision(5);
    std::cout << L << ' ' << G << std::endl;
    for(int i=0;i<L-1;i++)
        std::cout << std::fixed <<d(g) << ' ';
    std::cout << std::fixed << d(g) << std::endl;
}
