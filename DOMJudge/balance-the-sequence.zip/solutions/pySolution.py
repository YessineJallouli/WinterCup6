import sys

def main():
    T = int(input().strip())
    for _ in range(T):
        n = int(input().strip())
        s = input().strip()
        pr = [0] * (n + 1)
        for i in range(1, n + 1):
            pr[i] = pr[i - 1] + 1 if s[i - 1] == '(' else pr[i - 1] - 1
        idmn = 0
        idmx = 0
        for i in range(n):
            if pr[i] < 0:
                idmx = i
        for i in range(n - 1, -1, -1):
            if pr[i] < 0:
                idmn = i
        L = 0
        R = idmx
        for i in range(idmn + 1):
            if pr[L] < pr[i]:
                L = i
        for i in range(idmx, n+1):
            if pr[R] < pr[i]:
                R = i
        id = 0
        for i in range(n + 1):
            if pr[i] > pr[id]:
                id = i
        L += 1
        print(L, R)

if __name__ == '__main__':
    sys.exit(main())
