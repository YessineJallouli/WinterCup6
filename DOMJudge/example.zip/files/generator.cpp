//
// Created by ramizouari on 28/01/24.
//
#include <iostream>

int main(int argc, char** argv)
{
    int n=std::stoi(argv[1]);
    std::cout << n << '\n';
}
